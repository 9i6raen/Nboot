import sounddevice as sd
import numpy as np
import openai
from scipy.io.wavfile import write
import soundfile as sf
from pathlib import Path
import replicate
import vosk

# Configura tu clave de API de OpenAI y de replicate
openai.api_key = "sk-proj-Monp510MpH7dJIzP8OU0T3BlbkFJlTHOTET0u4OYh0m6tdEs"
replicate_api_token = "r8_RAAHI3Gr7K6LQKwNOmJodPKA9K4i8MY1t7M3n"

# Configuración para activación por comando de voz
trigger_word = "nevil"  
model = vosk.Model("model/vosk-model-smal")  

# Parámetros de grabación
fs = 16000  
duration = 5  

def escuchar_comando_activacion():
    print("Esperando la palabra clave...")
    while True:
        audio = sd.rec(int(2 * fs), samplerate=fs, channels=1, dtype='int16')
        sd.wait()
        audio_data = np.frombuffer(audio, np.int16)
        
        
        recognizer = vosk.KaldiRecognizer(model, fs)
        if recognizer.AcceptWaveform(audio_data.tobytes()):
            texto = recognizer.Result()
            if trigger_word in texto.lower():
                print("¡Palabra clave detectada!")
                return True

def grabar_audio():
    print("Grabando...")
    audio = sd.rec(int(duration * fs), samplerate=fs, channels=1, dtype='int16')
    sd.wait()
    write('input.wav', fs, audio)
    print("Grabación completa")
    return 'input.wav'

def transcribir_audio(archivo_audio):
    with open(archivo_audio, "rb") as audio_file:
        transcript = openai.Audio.transcribe("whisper-1", audio_file)
    return transcript['text']

def obtener_respuesta_chatgpt(texto):
    response = openai.Completion.create(
        model="gpt-4o-mini",
        prompt=texto,
        max_tokens=150,
        n=1,
        stop=None,
        temperature=0.7,
    )
    return response.choices[0].text.strip()

def sintetizar_voz_respuesta(respuesta):
    output = replicate.run(
        "lucataco/xtts-v2:684bc3855b37866c0c65add2ff39c78f3dea3f4ff103a436465326e0f438d55e",
        input={
            "text": respuesta,
            "speaker": "https://example.com/voice.wav", 
            "language": "es",
            "cleanup_voice": False
        },
        api_token=replicate_api_token
    )
    return output

def reproducir_audio(archivo_voz):
    data, fs = sf.read(archivo_voz, dtype='float32')
    sd.play(data, fs)
    sd.wait()

if __name__ == "__main__":
    while True:
        if escuchar_comando_activacion():
            archivo_audio = grabar_audio()
            texto = transcribir_audio(archivo_audio)
            print(f"Texto transcrito: {texto}")
            
            respuesta = obtener_respuesta_chatgpt(texto)
            print(f"Respuesta del Chatbot: {respuesta}")
            
            archivo_voz = sintetizar_voz_respuesta(respuesta)
            reproducir_audio(archivo_voz)
