import sounddevice as sd
import numpy as np
import openai
import soundfile as sf
from pathlib import Path
import requests
import vosk
import json

# Configura tu clave de API de OpenAI y de Replicate
openai.api_key = "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"
replicate_api_token = "r8_RAAHI3Gr7K6LQKwNOmJodPKA9K4i8MY1t7M3n"

# Configuración para activación por comando de voz
trigger_word = "nevil"  
model = vosk.Model("model/vosk-model-small-en-us")  

# Parámetros de grabación
fs = 16000  
duration = 5  

def escuchar_comando_activacion():
    print("Esperando la palabra clave...")
    while True:
        audio = sd.rec(int(2 * fs), samplerate=fs, channels=1, dtype='int16')
        sd.wait()
        audio_data = np.frombuffer(audio, np.int16)
        
        recognizer = vosk.KaldiRecognizer(model, fs)
        if recognizer.AcceptWaveform(audio_data.tobytes()):
            texto = json.loads(recognizer.Result())['text']
            if trigger_word in texto.lower():
                print("¡Palabra clave detectada!")
                return True

def grabar_audio():
    print("Grabando...")
    audio = sd.rec(int(duration * fs), samplerate=fs, channels=1, dtype='int16')
    sd.wait()
    sf.write('input.wav', audio, fs)
    print("Grabación completa")
    return 'input.wav'

def transcribir_audio(archivo_audio):
    with open(archivo_audio, "rb") as audio_file:
        transcript = openai.Audio.transcribe("whisper-1", audio_file)
    return transcript['text']

def obtener_respuesta_chatgpt(texto):
    response = openai.Completion.create(
        model="gpt-4",
        prompt=texto,
        max_tokens=150,
        n=1,
        stop=None,
        temperature=0.7,
    )
    return response.choices[0].text.strip()

def sintetizar_voz_respuesta(respuesta):
    headers = {
        "Authorization": f"Token {replicate_api_token}",
        "Content-Type": "application/json"
    }
    data = {
        "input": {
            "text": respuesta,
            "speaker": "en_us_male",
            "language": "es",
            "cleanup_voice": False
        }
    }
    response = requests.post(
        "https://api.replicate.com/v1/predictions",
        headers=headers,
        json=data
    )
    response_json = response.json()
    audio_url = response_json.get('output', '')
    return audio_url

def reproducir_audio(url_audio):
    response = requests.get(url_audio)
    with open('output.wav', 'wb') as f:
        f.write(response.content)
    data, fs = sf.read('output.wav', dtype='float32')
    sd.play(data, fs)
    sd.wait()

if __name__ == "__main__":
    while True:
        if escuchar_comando_activacion():
            archivo_audio = grabar_audio()
            texto = transcribir_audio(archivo_audio)
            print(f"Texto transcrito: {texto}")
            
            respuesta = obtener_respuesta_chatgpt(texto)
            print(f"Respuesta del Chatbot: {respuesta}")
            
            url_voz = sintetizar_voz_respuesta(respuesta)
            reproducir_audio(url_voz)
